# AETHER OS — AMD64 Live ISO Builder

This repository builds a **bootable Debian 13 (Trixie) live ISO for x86_64 / AMD64 PCs**.
The build runs on a native AMD64 GitHub Actions runner. It is deliberately not built inside
Cortex's ARM64 Ubuntu environment: live-build needs to execute target-architecture programs,
so this project uses GitHub Actions' x86_64 runner for the actual ISO build.

## What is included

- Debian 13 live system, Linux kernel and Debian firmware packages
- BIOS + UEFI boot support via GRUB 2
- Hyprland Wayland compositor and Caelestia shell source integration
- Quickshell, Caelestia CLI and Caelestia dotfiles (pulled from their upstream Git repositories at build time)
- PipeWire / WirePlumber audio and NetworkManager networking
- C, C++, Rust, Lua and NASM development tools
- Firefox ESR, Foot, Thunar, Waybar and common Wayland utilities

The build uses Debian's Trixie backports for Hyprland and Quickshell where required. The
Caelestia shell and its Material 3 shapes module are built from their upstream source during
the image build. Upstream Caelestia repositories can change; the workflow logs make failures
visible rather than silently claiming that the shell was installed.

## Build the ISO from your Huawei tablet

1. Extract this ZIP.
2. Create a new GitHub repository named `AETHER-OS`.
3. Upload the **contents** of the extracted `AETHER-OS` folder to the repository root, including
   the hidden `.github` folder. Do not upload the ZIP as a single file.
4. Open the repository's **Actions** tab. Enable Actions if GitHub asks.
5. Select **Build AETHER OS ISO** and tap **Run workflow**. A push to `main` also starts a build.
6. When the workflow finishes successfully, open that run, scroll to **Artifacts**, and download
   `AETHER-OS-01-iso`. Extract the downloaded artifact ZIP to get `AETHER-OS-01.iso`.

The ISO is built remotely. It will not appear automatically in Cortex or in your tablet's
Downloads folder; download the Actions artifact in the browser and then move the ISO to
`/storage/emulated/0/Download` using your file manager.

## Cortex / local build

Cortex on your MatePad is ARM64, while this ISO targets AMD64. The local script intentionally
stops with a clear message on ARM64 instead of attempting a broken cross-build. Use GitHub
Actions above for the actual ISO.

On a native Debian/Ubuntu AMD64 machine with live-build installed, run:

```bash
sudo apt update
sudo apt install -y live-build debootstrap xorriso squashfs-tools grub-pc-bin grub-efi-amd64-bin
sudo ./scripts/build-iso.sh
```

The output is `dist/AETHER-OS-01.iso`.

## Live session

The live session is configured for the `aether` user with automatic Hyprland login. The live
account is for testing; do not use the live image as a secured installed system without setting
passwords and reviewing the configuration first.

## Notes

- Hardware support comes primarily from the Linux kernel and Debian firmware packages. The
  included compiler/assembler toolchains are for development; they are not a replacement for
  kernel drivers.
- This is a live image, not a graphical hard-drive installer. It boots and runs from USB/RAM.
- This first builder is a reproducible starting point, not a claim that every PC GPU, Wi-Fi
  adapter or peripheral has been tested.
- Upstream components retain their own licenses. See the respective Debian, Hyprland,
  Quickshell and Caelestia project repositories for their terms.
