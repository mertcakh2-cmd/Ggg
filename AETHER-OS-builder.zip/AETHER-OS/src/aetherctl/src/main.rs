use std::fs;
use std::process::Command;

fn read_os_release(key: &str) -> Option<String> {
    let content = fs::read_to_string("/etc/os-release").ok()?;
    content.lines().find_map(|line| {
        let (k, v) = line.split_once('=')?;
        if k == key {
            Some(v.trim_matches('"').to_string())
        } else {
            None
        }
    })
}

fn main() {
    let version = read_os_release("VERSION").unwrap_or_else(|| "development".into());
    let kernel = Command::new("uname")
        .arg("-r")
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_else(|| "unknown".into());

    println!("AETHER OS {version}");
    println!("Kernel: {kernel}");
    println!("Architecture: x86_64 / AMD64 target");
    println!("Desktop: Hyprland + Caelestia");
}
