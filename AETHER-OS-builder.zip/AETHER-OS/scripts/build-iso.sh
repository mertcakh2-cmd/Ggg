#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ "$(dpkg --print-architecture 2>/dev/null || true)" != "amd64" || "$(uname -m)" != "x86_64" ]]; then
    cat >&2 <<'MSG'
AETHER OS targets AMD64/x86_64.
This machine is not a native AMD64 build host. Cortex on ARM64 cannot run this
live-build pipeline reliably. Push this project to GitHub and run its Actions workflow.
MSG
    exit 2
fi

if [[ "$(id -u)" -ne 0 ]]; then
    echo "Run this script with sudo: sudo ./scripts/build-iso.sh" >&2
    exit 1
fi

for tool in lb debootstrap xorriso mksquashfs; do
    command -v "$tool" >/dev/null 2>&1 || {
        echo "Missing required build tool: $tool" >&2
        exit 1
    }
done

mkdir -p dist config/includes.chroot/usr/src/aetherctl
cp -a "$ROOT_DIR/src/aetherctl/." config/includes.chroot/usr/src/aetherctl/
rm -f dist/AETHER-OS-01.iso dist/SHA256SUMS

# Clean previous live-build output while preserving config/.
lb clean --purge || true

lb config \
    --distribution trixie \
    --architectures amd64 \
    --binary-image iso-hybrid \
    --bootloaders grub-pc,grub-efi \
    --archive-areas "main contrib non-free non-free-firmware" \
    --linux-packages linux-image \
    --linux-flavours amd64 \
    --iso-application "AETHER OS" \
    --iso-publisher "AETHER Project" \
    --iso-preparer "AETHER live-build" \
    --iso-volume "AETHER_01" \
    --grub-splash "$ROOT_DIR/assets/aether-grub.png" \
    --bootappend-live "boot=live components username=aether hostname=aether-os quiet splash" \
    --checksums sha256

lb build

ISO_PATH="$(find "$ROOT_DIR" -maxdepth 1 -type f -name '*.iso' -print -quit)"
if [[ -z "$ISO_PATH" || ! -s "$ISO_PATH" ]]; then
    echo "live-build completed but no ISO file was found in $ROOT_DIR" >&2
    exit 1
fi

mv "$ISO_PATH" "$ROOT_DIR/dist/AETHER-OS-01.iso"
sha256sum "$ROOT_DIR/dist/AETHER-OS-01.iso" | tee "$ROOT_DIR/dist/SHA256SUMS"
ls -lh "$ROOT_DIR/dist/AETHER-OS-01.iso"
